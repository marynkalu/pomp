# -*- coding: UTF-8 -*-

class Result:
    def __init__(self, date=None, description=None, author=None):
        self.date = date
        self.description = description
        self.author = author
